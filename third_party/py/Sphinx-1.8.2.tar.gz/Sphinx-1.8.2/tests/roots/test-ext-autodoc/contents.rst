
.. automodule:: autodoc_dummy_module
   :members:

.. automodule:: bug2437.autodoc_dummy_foo
   :members:

.. automodule:: autodoc_dummy_bar
   :members:
