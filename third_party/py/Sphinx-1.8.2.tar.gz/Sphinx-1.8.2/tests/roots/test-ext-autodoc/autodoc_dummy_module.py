from dummy import *   # NOQA


def test():
    """Dummy function using dummy.*"""
    dummy_function()   # NOQA
