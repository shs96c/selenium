class Foo(object):
    """Dummy class Foo."""
    pass
