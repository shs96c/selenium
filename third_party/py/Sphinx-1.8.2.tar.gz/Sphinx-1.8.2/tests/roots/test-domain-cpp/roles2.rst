Check that we don't crash just because we misuse a role.

.. cpp:class:: A

:cpp:func:`A`
