Literal Includes with Highlighted Lines
=======================================

.. literalinclude:: target.py
   :language: python
   :emphasize-lines: 5-6, 13-15, 24-

